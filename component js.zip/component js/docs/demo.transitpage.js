define({
  title: 'iki sek demo transite page',
  body: `
  <div class="page-container">
    <div class="container">
      <div class="page-header"><h1>cok neng kene<span class="animate"></span>china anyeng</h1></div>\
      <a href="#" class="btn btn-default">siht</a>
    </div>
  </div>
  `,
  init: function(pageData) {
    var $view = this
    
    $('.page-container', $view).trigger('spa:scroll')
  },
  beforeopen: function(pageData) {
    var $view = this,
        pushData = pageData.pushData,
        animate = pushData.animate || 'default'

    $('.animate', $view).text(animate)
  }
})