define({
  title: 'oy',
  body: '<nav class="navbar navbar-default navbar-static-top" role="navigation">\
    <div class="navbar-header">\
      <a class="navbar-brand" href="#">SPA</a>\
    </div>\
    <!--a href="#" class="btn btn-default navbar-btn btn-link pull-left"><span class="glyphicon glyphicon-align-justify"></span></a-->\
    <!--a href="#" class="btn btn-default navbar-btn btn-link pull-right">关于</a-->\
  </nav>\
  <div class="page-container-navbar">\
    <div class="container">\
      </p>\
\
      <a href="#demo/newpage" class="btn btn-sm btn-info">kepake</a>\
      <a href="#" data-panel="demoPanelSidemenu" class="btn btn-sm btn-info btn-demo-panel">kepake</a>\
      <a href="#" data-panel="demoPanelAlert" class="btn btn-sm btn-info btn-demo-panel">kepake</a>\
      <a href="#" data-panel="demoPanelConfirm" class="btn btn-sm btn-info btn-demo-panel">kepake</a>\
       <a href="#demo/transitpage" class="btn btn-sm btn-info btn-transitpage" data-animate="default">default</a>\
      </p>\
      <p>\
      <a href="#demo/transitpage" class="btn btn-sm btn-info btn-transitpage" data-animate="fadeIn">oy</a>\
      <a href="#demo/transitpage" class="btn btn-sm btn-info btn-transitpage" data-animate="fadeOut">oi</a>\
      </p>\
      <p>\
      <a href="#demo/transitpage" class="btn btn-sm btn-info btn-transitpage" data-animate="slideInLeft">slideInLeft</a>\
      <a href="#demo/transitpage" class="btn btn-sm btn-info btn-transitpage" data-animate="slideOutRight">slideOutRight</a>\
      </p>\
      <p>\
      <a href="#demo/transitpage" class="btn btn-sm btn-info btn-transitpage" data-animate="slideInRight">slideInRight</a>\
      <a href="#demo/transitpage" class="btn btn-sm btn-info btn-transitpage" data-animate="slideOutLeft">slideOutLeft</a>\
      </p>\
      <p>\
      <a href="#demo/transitpage" class="btn btn-sm btn-info btn-transitpage" data-animate="slideInUp">slideInUp</a>\
      <a href="#demo/transitpage" class="btn btn-sm btn-info btn-transitpage" data-animate="slideOutDown">slideOutDown</a>\
      </p>\
      <p>\
      <a href="#demo/transitpage" class="btn btn-sm btn-info btn-transitpage" data-animate="slideInDown">slideInDown</a>\
      <a href="#demo/transitpage" class="btn btn-sm btn-info btn-transitpage" data-animate="slideOutUp">slideOutUp</a>\
      </p>\
      <p>\
      <a href="#demo/transitpage" class="btn btn-sm btn-info btn-transitpage" data-animate="pushInLeft">pushInLeft</a>\
      <a href="#demo/transitpage" class="btn btn-sm btn-info btn-transitpage" data-animate="pushOutRight">pushOutRight</a>\
      </p>\
      <p>\
      <a href="#demo/transitpage" class="btn btn-sm btn-info btn-transitpage" data-animate="pushInRight">pushInRight</a>\
      <a href="#demo/transitpage" class="btn btn-sm btn-info btn-transitpage" data-animate="pushOutLeft">pushOutLeft</a>\
      </p>\
      <p>\
      <a href="#demo/transitpage" class="btn btn-sm btn-info btn-transitpage" data-animate="pushInUp">pushInUp</a>\
      <a href="#demo/transitpage" class="btn btn-sm btn-info btn-transitpage" data-animate="pushOutDown">pushOutDown</a>\
      </p>\
      <p>\
      <a href="#demo/transitpage" class="btn btn-sm btn-info btn-transitpage" data-animate="pushInDown">pushInDown</a>\
      <a href="#demo/transitpage" class="btn btn-sm btn-info btn-transitpage" data-animate="pushOutUp">pushOutUp</a>\
      </p>\
      <p>\
      <a href="#demo/transitpage" class="btn btn-sm btn-info btn-transitpage" data-animate="zoomIn">zoomIn</a>\
      <a href="#demo/transitpage" class="btn btn-sm btn-info btn-transitpage" data-animate="zoomOut">zoomOut</a>\
      </p>\
      <p>\
      <a href="#" class="btn btn-sm btn-info btn-transitpanel" data-animate="overlayInLeft">overlayInLeft</a>\
      <a href="#" class="btn btn-sm btn-default" disabled="disabled">overlayOutRight</a>\
      </p>\
      <p>\
      <a href="#" class="btn btn-sm btn-info btn-transitpanel" data-animate="overlayInRight">overlayInRight</a>\
      <a href="#" class="btn btn-sm btn-default" disabled="disabled">overlayOutLeft</a>\
      </p>\
      <p>\
      <a href="#" class="btn btn-sm btn-info btn-transitpanel" data-animate="overlayInUp">overlayInUp</a>\
      <a href="#" class="btn btn-sm btn-default" disabled="disabled">overlayOutDown</a>\
      </p>\
      <p>\
      <a href="#" class="btn btn-sm btn-info btn-transitpanel" data-animate="overlayInDown">overlayInDown</a>\
      <a href="#" class="btn btn-sm btn-default" disabled="disabled">overlayOutUp</a>\
      </p>\
      <p>\
      <a href="#" class="btn btn-sm btn-info btn-transitpanel" data-animate="revealInLeft">revealInLeft</a>\
      <a href="#" class="btn btn-sm btn-default" disabled="disabled">revealOutRight</a>\
      </p>\
      <p>\
      <a href="#" class="btn btn-sm btn-info btn-transitpanel" data-animate="revealInRight">revealInRight</a>\
      <a href="#" class="btn btn-sm btn-default" disabled="disabled">revealOutLeft</a>\
      </p>\
      <p>\
      <a href="#" class="btn btn-sm btn-info btn-transitpanel" data-animate="revealInUp">revealInUp</a>\
      <a href="#" class="btn btn-sm btn-default" disabled="disabled">revealOutDown</a>\
      </p>\
      <p>\
      <a href="#" class="btn btn-sm btn-info btn-transitpanel" data-animate="revealInDown">revealInDown</a>\
      <a href="#" class="btn btn-sm btn-default" disabled="disabled">revealOutUp</a>\
      </p>\
      <p>\
      <a href="#" class="btn btn-sm btn-info btn-transitpanel" data-animate="pushPartInLeft">pushPartInLeft</a>\
      <a href="#" class="btn btn-sm btn-default" disabled="disabled">pushPartOutRight</a>\
      </p>\
      <p>\
      <a href="#" class="btn btn-sm btn-info btn-transitpanel" data-animate="pushPartInRight">pushPartInRight</a>\
      <a href="#" class="btn btn-sm btn-default" disabled="disabled">pushPartOutLeft</a>\
      </p>\
      <p>\
      <a href="#" class="btn btn-sm btn-info btn-transitpanel" data-animate="pushPartInUp">pushPartInUp</a>\
      <a href="#" class="btn btn-sm btn-default" disabled="disabled">pushPartOutDown</a>\
      </p>\
      <p>\
      <a href="#" class="btn btn-sm btn-info btn-transitpanel" data-animate="pushPartInDown">pushPartInDown</a>\
      <a href="#" class="btn btn-sm btn-default" disabled="disabled">pushPartOutUp</a>\
      </p>\
      <div class="page-header"><h1>License</h1></div>\
      </p>\
    </div>\
  </div>\
  ',
  init: function(pageData) {
    var $view = this

  
    function getHash(url) {
      url = url || location.href
      return url.replace(/^[^#]*#?\/?(.*)\/?$/, '$1')
    }
    
    $('pre', $view).each(function(i, e) { hljs.highlightBlock(e) })
    
    $view.on('click', '.btn-demo-panel', function(event) {
      event.preventDefault()
      var $btn = $(this),
          panelid = $btn.attr('data-panel')
      
      $doc.trigger('spa:openpanel', [panelid])
    })

    $view.on('click', '.btn-transitpage', function(event) {
      event.preventDefault()
      var $btn = $(this),
          animate = $btn.attr('data-animate'),
          hash = getHash($btn.attr('href'))
      
      $doc.trigger('spa:navigate', {hash: hash, pushData: {animate: animate}})
    })

    $view.on('click', '.btn-transitpanel', function(event) {
      event.preventDefault()
      var $btn = $(this),
          animate = $btn.attr('data-animate')
      
      $doc.trigger('spa:openpanel', ['demoPanelTransit', {animate: animate}])
    })
    
    $('.page-container-navbar', $view).trigger('spa:scroll')
  }
})